import React, { useState, useEffect } from 'react';
import { db, auth } from '../firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';
import { UserService } from '../services/userService';
import { Shield, Key, Database, LogIn } from 'lucide-react';
import { motion } from 'framer-motion';

export default function SettingsPage() {
  const [keys, setKeys] = useState({ arcTrackerKey: '', metaForgeId: '', xboxToken: '' });
  const [user, setUser] = useState<any>(null);
  const [message, setMessage] = useState('');

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (userData) => {
      setUser(userData);
      if (userData?.uid) {
        const docRef = doc(db, 'users', userData.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setKeys({ 
            arcTrackerKey: data.arcTrackerKey || localStorage.getItem("arcTrackerUserKey") || '', 
            metaForgeId: data.metaForgeId || localStorage.getItem("metaforgeUserId") || '',
            xboxToken: data.xboxToken || localStorage.getItem("embark_session_token") || '' 
          });
        } else {
          // Fallback to local storage if firestore is empty for this new user
          setKeys({
            arcTrackerKey: localStorage.getItem("arcTrackerUserKey") || '',
            metaForgeId: localStorage.getItem("metaforgeUserId") || '',
            xboxToken: localStorage.getItem("embark_session_token") || ''
          });
          // Fallback to local storage if firestore is empty for this new user
          setKeys({
            arcTrackerKey: localStorage.getItem("arcTrackerUserKey") || '',
            metaForgeId: localStorage.getItem("metaforgeUserId") || ''
          });
        }
      }
    });
    return () => unsub();
  }, []);

  const handleDiscordLogin = async () => {
    try {
      await UserService.loginWithDiscord();
    } catch (e) {
      setMessage('Social sync failed. Check popup blockers.');
    }
  };

  const saveKeys = async () => {
    if (!user?.uid) return;
    try {
      await setDoc(doc(db, 'users', user.uid), {
        discordId: user.providerData[0]?.uid || user.uid,
        arcTrackerKey: keys.arcTrackerKey,
        metaForgeId: keys.metaForgeId,
        xboxToken: keys.xboxToken
      }, { merge: true });
      
      // Also save to localStorage for immediate availability in components
      localStorage.setItem("arcTrackerUserKey", keys.arcTrackerKey);
      localStorage.setItem("metaforgeUserId", keys.metaForgeId);
      localStorage.setItem("embark_session_token", keys.xboxToken);
      
      setMessage('Settings saved successfully! Operative data synced.');
    } catch (error) {
      setMessage('Error saving settings.');
    }
  };

  if (!user) return (
    <div className="py-12 text-center">
      <div className="raider-box p-6 max-w-sm mx-auto bg-[#050505]">
        <div className="scanline" />
        <Shield className="w-8 h-8 text-[#71717A] mx-auto mb-4 opacity-30" />
        <h3 className="text-lg font-black text-white uppercase tracking-widest mb-1">SECURE LINK</h3>
        <p className="text-[9px] text-[#71717A] mb-6 font-data uppercase tracking-widest">Establish Discord identity for API sync.</p>
        <button 
          onClick={handleDiscordLogin}
          className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-[#5865F2] hover:bg-[#4752C4] text-white font-bold uppercase tracking-[0.15em] text-sm transition-all raider-box"
        >
          <LogIn className="w-3.5 h-3.5" />
          LINK DISCORD
        </button>
        <p className="text-[8px] text-[#444] mt-4 font-mono">Use /api/auth/discord if popup blocked</p>
      </div>
    </div>
  );

  return (
    <div className="space-y-6 max-w-2xl mx-auto py-8">
      <div className="flex items-center gap-4 border-b border-[#222] pb-6">
        <div className="p-3 bg-[#111] border border-[#39FF14]/30 raider-box">
          <Key className="w-6 h-6 text-[#39FF14] shiesty-glow" />
        </div>
        <div>
          <h2 className="text-2xl font-black text-white uppercase tracking-widest">Secure Sync</h2>
          <p className="text-[10px] text-[#39FF14] font-data uppercase tracking-[0.4em]">ARCTRACKER_METAFORGE_INTERFACE</p>
        </div>
      </div>

      <div className="raider-box p-8 bg-[#080808] relative overflow-hidden">
        <div className="scanline" />
        <div className="space-y-8 relative z-10">
          <div className="space-y-3">
             <label className="text-[10px] text-[#71717A] font-data uppercase tracking-widest flex items-center gap-2">
               <Database className="w-3 h-3 text-[#39FF14]" /> ArcTracker User Key
             </label>
             <input 
               type="password"
               className="w-full p-4 bg-black border border-[#222] text-[#39FF14] font-mono text-sm focus:border-[#39FF14] outline-none transition-colors raider-box" 
               placeholder="arc_u1_..." 
               value={keys.arcTrackerKey} 
               onChange={e => setKeys({...keys, arcTrackerKey: e.target.value})} 
             />
             <p className="text-[8px] text-[#444] font-data uppercase">Used for private raid logs and stash telemetry.</p>

             <label className="text-[10px] text-[#71717A] font-data uppercase tracking-widest flex items-center gap-2">
               <Shield className="w-3 h-3 text-[#FF6B35]" /> Xbox Session Token
             </label>
             <input 
               type="password"
               className="w-full p-4 bg-black border border-[#222] text-[#FF6B35] font-mono text-sm focus:border-[#FF6B35] outline-none transition-colors raider-box" 
               placeholder="__session=..." 
               value={keys.xboxToken} 
               onChange={e => setKeys({...keys, xboxToken: e.target.value})} 
             />
             <p className="text-[8px] text-[#444] font-data uppercase">Get from id.embark.games network tab for live Xbox stash.</p>
          </div>

          <div className="space-y-3">
             <label className="text-[10px] text-[#71717A] font-data uppercase tracking-widest flex items-center gap-2">
               <Shield className="w-3 h-3 text-[#FFB800]" /> MetaForge UUID
             </label>
             <input 
               type="text"
               className="w-full p-4 bg-black border border-[#222] text-[#FFB800] font-mono text-sm focus:border-[#FFB800] outline-none transition-colors raider-box" 
               placeholder="00000000-0000-0000-0000-000000000000" 
               value={keys.metaForgeId} 
               onChange={e => setKeys({...keys, metaForgeId: e.target.value})} 
             />
             <p className="text-[8px] text-[#444] font-data uppercase">Used for trial leaderboards and raider stats.</p>
          </div>

          <button 
            onClick={saveKeys} 
            className="w-full py-5 bg-[#39FF14] text-black font-black uppercase tracking-[0.3em] hover:bg-white transition-all shiesty-interactive shadow-[0_0_20px_rgba(57,255,20,0.2)]"
          >
            COMMIT_SYNC_PROTOCOLS
          </button>
        </div>
      </div>

      {message && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-[#39FF14]/10 border border-[#39FF14]/30 text-[#39FF14] text-center text-[10px] font-black uppercase tracking-widest raider-box"
        >
          {message}
        </motion.div>
      )}
    </div>
  );
}
