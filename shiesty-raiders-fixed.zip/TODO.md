# Shiesty-Raiders Fix Deployment & Stats Issues

## ✅ 1. PM2 ecosystem.config.js created
PM2 config for shiesty-raiders (npm start) + shiesty-bot (tsx bot.ts).
Logs: ./logs/raiders-combined.log, ./logs/bot-combined.log.

## ✅ 2. Fixed server.ts 
- Removed broken bot spawn (npx ENOENT).
- Bot now PM2-managed, server clean.

## ✅ 3. Fixed apiEngine.ts (stats 0 → v2/profile)
- Removed v1/stats/inventory/blueprints (404).
- Fallback v2 profile + stash calculations.
- Xbox key now works for profile/stash/rounds.

## [ ] 4. Deploy & test
**Ubuntu server:**
```
cd /home/ubuntu/shiesty-raiders
npm ci
npm run build
pm2 delete all
pm2 start ecosystem.config.js
pm2 save
pm2 startup
pm2 logs shiesty-raiders
```

**Verify:**
```
curl localhost:3000/ping  # pong
curl 'localhost:3000/api/stats?userKey=arc_u1_n6BApGMOBtzF9TULvhqa3dTMF2-MPHr5'
curl shiesty.me/api/profile  # proxy
```
Dashboard stats non-zero with Xbox key.
**On Ubuntu server (/home/ubuntu/shiesty-raiders):**
```
npm ci
npm run build
pm2 delete all
pm2 start ecosystem.config.js --env production
pm2 save
pm2 startup
pm2 logs
```

**Test:**
```
curl http://localhost:3000/ping  # pong
curl 'http://localhost:3000/api/stats?userKey=YOUR_KEY'
curl 'http://shiesty.me/api/blueprints'  # proxy test
```

## [ ] 5. Fix dashboard stats (Xbox key)
- v2/profile + MetaForge raider/ID → non-zero stats.
- Settings Xbox key → passes to /api/stats?userKey=...

## [ ] 6. Firestore (optional)
- Discord login → save arcTrackerKey/metaforgeId to 'users/{discordId}'.

**Next**: Test ecosystem locally (`pm2 start ecosystem.config.js --env production`), then fix apiEngine.ts for stats.

